#!/bin/bash

SYSTEM_DIR=$1
CURRENT_DIR=$2
FACTORY=$3
VERSION=$4
PLATFORM_PUBLIC=$5
CUSTOMER_PUBLIC_DIR=$6
APP=app
PRIV_APP=priv-app
ICS_REMOVE_UNUSED_PACKAGE=false
JB_REMOVE_UNUSED_PACKAGE=true
CUSTOM_NEED_CUBER=false
CUSTOM_NEED_GAPPS=true
PRIV_REMOVE_PACKAGE=true

CONTEXT_DIR=$CURRENT_DIR/private.system


BUILD_NAME="Normal-"
BUILD_VERSION="$VERSION"
BUILD_DATE="-`date +%Y%m%d`"
BUILD_ID="$BUILD_NAME$BUILD_VERSION$BUILD_DATE"
echo "ro.build.id=$BUILD_ID" > $CONTEXT_DIR/tmp.prop
echo "ro.sdmc.firmware.ver=$BUILD_VERSION" >> $CONTEXT_DIR/tmp.prop
cat $CONTEXT_DIR/build_device.prop >> $CONTEXT_DIR/tmp.prop

cp -rf $PLATFORM_PUBLIC/system/* $SYSTEM_DIR/
cp -rf $PLATFORM_PUBLIC/google_new/* $SYSTEM_DIR/
cp -rf $PLATFORM_PUBLIC/DLNA/* $SYSTEM_DIR/
#cp -rf $PLATFORM_PUBLIC/drmPlayer/* $SYSTEM_DIR/
cp -rf $PLATFORM_PUBLIC/verimatrix/* $SYSTEM_DIR/


echo "CURRENT_DIR is $CURRENT_DIR"
echo "CONTEXT_DIR is $CONTEXT_DIR"
echo "SYSTEM_DIR is $SYSTEM_DIR"

cp -rf $CONTEXT_DIR/tmp.prop $SYSTEM_DIR/sdmc.prop
cp -rf $CONTEXT_DIR/app/* $SYSTEM_DIR/app
cp -rf $CONTEXT_DIR/priv-app/* $SYSTEM_DIR/priv-app
cp -rf $CONTEXT_DIR/lib/* $SYSTEM_DIR/lib
cp -rf $CONTEXT_DIR/etc/* $SYSTEM_DIR/etc
cp -rf $CONTEXT_DIR/usr/* $SYSTEM_DIR/usr
cp -rf $CONTEXT_DIR/media/* $SYSTEM_DIR/media
cp -rf $CONTEXT_DIR/xbin/* $SYSTEM_DIR/xbin
cp -rf $CONTEXT_DIR/bin/* $SYSTEM_DIR/bin
cp -rf $CONTEXT_DIR/xbmc/* $SYSTEM_DIR/xbmc
cp -rf $CONTEXT_DIR/framework/* $SYSTEM_DIR/framework
cp -rf $CONTEXT_DIR/web/ $SYSTEM_DIR/web
cp -rf $CONTEXT_DIR/preinstall/ $SYSTEM_DIR/preinstall


rm -rf $SYSTEM_DIR/app/SmartRemote
rm -rf $SYSTEM_DIR/app/PPPoE
rm -rf $SYSTEM_DIR/app/MboxLauncher
rm -rf $SYSTEM_DIR/app/Miracast
rm -rf $SYSTEM_DIR/priv-app/Launcher2
rm -rf $SYSTEM_DIR/app/FileBrowser
rm -rf $SYSTEM_DIR/app/DeskClock
rm -rf $SYSTEM_DIR/app/OTAUpgrade
rm -rf $SYSTEM_DIR/priv-app/TvSettings
rm -rf $SYSTEM_DIR/priv-app/DLNA
#delete youtube.
rm -rf $SYSTEM_DIR/app/YouTubeLeanback
rm -rf $SYSTEM_DIR/app/MetroUI.apk
#20160819 edit to enable install unknown app.
rm -rf $SYSTEM_DIR/priv-app/SettingsProvider