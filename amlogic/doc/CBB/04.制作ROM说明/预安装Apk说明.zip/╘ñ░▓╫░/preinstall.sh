#!/system/bin/sh

MARK_DATA=/data/local/symbol_thirdpart_apks_installed
MARK_SYSTEM=/system/local/symbol_thirdpart_apks_installed
PKGS=/system/preinstall/

if [ ! -e $MARK_DATA ] || [ ! -e $MARK_SYSTEM ]; then
echo "booting the first time, so pre-install some APKs."
#pm uninstall tv.hooq.android 
#rm -rf /data/data/tv.hooq.android/
#cp /system/lib/hooq-1-0-0-59-prod-release.apk /system/priv-app/
#chmod 777  /system/priv-app/hooq-1-0-0-59-prod-release.apk
#cp /system/lib/hooq-1-0-0-59-prod-release.apk /system/priv-app/
busybox find $PKGS -name "*\.apk" -exec sh /system/bin/pm install -r {} \;

# NO NEED to delete these APKs since we keep a mark under data partition.
# And the mark will be wiped out after doing factory reset, so you can install
# these APKs again if files are still there.
# busybox rm -rf $PKGS
mkdir -p $MARK_DATA
mkdir -p $MARK_SYSTEM
#busybox find $PKGS -name "*\.apk" -exec sh /system/bin/pm install {} \;
echo "OK, installation complete."
fi

