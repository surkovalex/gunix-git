/******************************************************************************
Copyright (c) 2010,ShenZhen Coship Electronic Ltd Co.
All rights reserved.

File Name: CS_netcmd.c
Summary: 
Current Version: $Revision$
Author: Nfer

History:
$Log$

*******************************************************************************/

/******************************************************************************
 *                                 Header file                                *
 ******************************************************************************/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "udi2_os.h"
#include "udi2_typedef.h"
#include "udi2_toolset.h"
#include "udiplus_os.h"
#include "udiplus_typedef.h"
#include "udiplus_debug.h"
#include "cs_ir_plus.h"
#include "udi2_input.h"

#include "CS_netcmd.h"

/******************************************************************************
 *                                 Local Define                               *
 ******************************************************************************/
#define SOCKET_PORT				(20100) 
#define SOCKET_QUEUE_MAXNUM		(5) 
#define SOCKET_CMD_MAXLEN		(256) 
#define SOCKETADDRLEN			sizeof(CSUDISockAddr_IN_S)
#define INVALCMDRTN				"[START]#0:0#02#[END]"

static int s_sockfd = -1;  	// listen on sockfd
static int s_newfd 	= -1;	// new connection on newfd

static CSUDISockAddr_IN_S s_sServerAddr = {0};	// server address information
static CSUDISockAddr_IN_S s_sClientAddr = {0};	//connector's address information

static BOOL 		s_bNetCmdInitFlag 	= FALSE;
static HCSHANDLE	s_hNetCmdThreadID 	= NULL;

static	CSNetCmdCallback s_pCSNetCmdCallback = NULL;

extern void UI_RemoteControlUserProc(CSHDICallbackType tCallbackType, void *param);
static int iProcess(BYTE * aucCmd);
static int iCheckCmd(BYTE * aucCmd, int * pnUserData);
static void iNetCmdThread(void);
static void iGetReturnBuffer(BYTE * aucBuffer, int nRet);

/******************************************************************************
 *                                 Static Function Declare                    *
  ******************************************************************************/
CSNETCMDRet_E CSNetCmdInit(void)
{
	int yes = 1;
	
	CSDEBUG(NETCMD_MODULE_NAME, INFO_LEVEL, "[%s:%d] CSNetCmdInit ... \n", __FUNCTION__, __LINE__ );
	if (s_bNetCmdInitFlag)
    {
        CSDEBUG(NETCMD_MODULE_NAME, INFO_LEVEL, "[%s:%d] already init .\n", __FUNCTION__, __LINE__);
        return EM_NETCMD_SUCCESS;
    }

	//socket
	if (-1 == (s_sockfd = CSUDISOCKSocket(CSUDI_AF_INET, CSUDI_SOCK_STREAM, 0)))
	{
        CSDEBUG(NETCMD_MODULE_NAME, FATAL_LEVEL, "[%s:%d] CSUDISOCKSocket failed .\n", __FUNCTION__, __LINE__);
        return EM_NETCMD_FAILURE;
    }

	//set opt
    if (-1 == CSUDISOCKSetSockOpt(s_sockfd, CSUDI_SOL_SOCKET, CSUDI_SO_REUSEADDR, &yes, sizeof(yes))) 
    {
        CSDEBUG(NETCMD_MODULE_NAME, FATAL_LEVEL, "[%s:%d] CSUDISOCKSetSockOpt failed .\n", __FUNCTION__, __LINE__);
        return EM_NETCMD_FAILURE;
    }

	//bind
	memset(&s_sServerAddr, 0x0, sizeof(s_sServerAddr)); 
	s_sServerAddr.sin_family 		= CSUDI_AF_INET; 
	s_sServerAddr.sin_port 			= CSUDISOCKHtons(SOCKET_PORT); 
	s_sServerAddr.sin_addr.s_addr 	= CSUDI_INADDR_ANY;
	
	if (-1 == CSUDISOCKBind(s_sockfd, (CSUDISockAddr_S *)&s_sServerAddr, SOCKETADDRLEN))
	{
		CSDEBUG(NETCMD_MODULE_NAME, FATAL_LEVEL, "[%s:%d] CSUDISOCKBind failed .\n", __FUNCTION__, __LINE__);
		return EM_NETCMD_FAILURE;
	}

	//listen
	if (-1 == CSUDISOCKListen(s_sockfd, SOCKET_QUEUE_MAXNUM))
	{
		CSDEBUG(NETCMD_MODULE_NAME, FATAL_LEVEL, "[%s:%d] CSUDISOCKListen failed .\n", __FUNCTION__, __LINE__);
		return EM_NETCMD_FAILURE;
	}

	
    
	CSNetCmdRegisterCallback((CSNetCmdCallback)UI_RemoteControlUserProc);	
	s_bNetCmdInitFlag = TRUE;
	
	CSDEBUG(NETCMD_MODULE_NAME, INFO_LEVEL, "[%s:%d] CSNetCmdInit success \n", __FUNCTION__, __LINE__ );
	return EM_NETCMD_SUCCESS;
}

CSNETCMDRet_E CSNetCmdStart(void)
{
	CSDEBUG(NETCMD_MODULE_NAME, INFO_LEVEL, "[%s:%d] CSNetCmdStart ... \n", __FUNCTION__, __LINE__ );
	if (!s_bNetCmdInitFlag)
	{
		if (EM_NETCMD_SUCCESS != CSNetCmdInit())
		{
			CSDEBUG(NETCMD_MODULE_NAME, FATAL_LEVEL, "[%s:%d] CSNetCmdInit failed .\n", __FUNCTION__, __LINE__);
			return EM_NETCMD_FAILURE;
		}
	}

	//create Thread
	CSUDIOSThreadCreate("NetCmd", 0, 8*1024, iNetCmdThread, NULL, &s_hNetCmdThreadID);
    if (s_hNetCmdThreadID == (HCSHANDLE)NULL)
    {
    	CSDEBUG(NETCMD_MODULE_NAME, FATAL_LEVEL, "[%s:%d] CSUDIOSThreadCreate failed .\n", __FUNCTION__, __LINE__);
        return EM_NETCMD_FAILURE;
    }

	CSDEBUG(NETCMD_MODULE_NAME, INFO_LEVEL, "[%s:%d] CSNetCmdStart success \n", __FUNCTION__, __LINE__ );
	return EM_NETCMD_SUCCESS;
}



CSNETCMDRet_E CSNetCmdStop(void)
{
	CSDEBUG(NETCMD_MODULE_NAME, INFO_LEVEL, "[%s:%d] CSNetCmdStop ... \n", __FUNCTION__, __LINE__ );
	if (s_hNetCmdThreadID != NULL)
	{
		CSUDIOSThreadDestroy(s_hNetCmdThreadID);
		s_hNetCmdThreadID = NULL;
	}	

	if (s_newfd > 0)
	{
		CSUDISOCKClose(s_newfd);
		s_newfd = -1;
	}	
	
	CSDEBUG(NETCMD_MODULE_NAME, INFO_LEVEL, "[%s:%d] CSNetCmdStop success \n", __FUNCTION__, __LINE__ );
	return EM_NETCMD_SUCCESS;
}

CSNETCMDRet_E CSNetCmdDestroy(void)
{
	CSDEBUG(NETCMD_MODULE_NAME, INFO_LEVEL, "[%s:%d] CSNetCmdDestroy ... \n", __FUNCTION__, __LINE__ );
	if (s_hNetCmdThreadID != NULL)
	{
		CSUDIOSThreadDestroy(s_hNetCmdThreadID);
		s_hNetCmdThreadID = NULL;
	}
	
	if (s_newfd > 0)
	{
		CSUDISOCKClose(s_newfd);
		s_newfd = -1;
	}
	
	if (s_sockfd > 0)
	{
		CSUDISOCKClose(s_sockfd);
		s_sockfd = -1;
	}

	s_bNetCmdInitFlag = FALSE;
	
	CSDEBUG(NETCMD_MODULE_NAME, INFO_LEVEL, "[%s:%d] CSNetCmdDestroy success \n", __FUNCTION__, __LINE__ );
	return EM_NETCMD_SUCCESS;
}

CSNETCMDRet_E CSNetCmdRegisterCallback( CSNetCmdCallback CmdSendCallback )
{
	s_pCSNetCmdCallback = CmdSendCallback;
	return EM_NETCMD_SUCCESS;
}
static int iProcess(BYTE * aucCmd)
{
	int nUserData = -1;
	int nRet = -1;
	CSIRKeyParam_t sIRKey = {0};
	
	if (NULL == aucCmd)
	{
		CSDEBUG(NETCMD_MODULE_NAME, ERROR_LEVEL, "[%s:%d] illegal param \n", __FUNCTION__, __LINE__ );
		return EM_NETCMD_INVALPARA;
	}

	nRet = iCheckCmd(aucCmd, &nUserData);
	if (EM_NETCMD_SUCCESS != nRet)
	{
		CSDEBUG(NETCMD_MODULE_NAME, ERROR_LEVEL, "[%s:%d] iCheckCmd failed \n", __FUNCTION__, __LINE__ );
		return nRet;
	}

	if (NULL == s_pCSNetCmdCallback)
	{
		CSDEBUG(NETCMD_MODULE_NAME, ERROR_LEVEL, "[%s:%d] s_pCSNetCmdCallback NULL \n", __FUNCTION__, __LINE__ );
		return EM_NETCMD_FAILURE;
	}

	sIRKey.m_dwIRLogicValue = nUserData;
	sIRKey.m_enmIRKeyStatus = CSIR_KEY_RELEASE;		
	s_pCSNetCmdCallback(CSHDI_CALLBACK_IR, &sIRKey);
	
	CSDEBUG(NETCMD_MODULE_NAME, INFO_LEVEL, "[%s:%d] iProcess success \n", __FUNCTION__, __LINE__ );
	return EM_NETCMD_SUCCESS;
}
static int iCheckCmd(BYTE * aucCmd, int *pnUserData)
{
	char * pTemp;
	char * pSeperatorStart;
	char * pSeperatorMid;
	char * pSeperatorEnd;
	int nCmdType = -1;
	int nCmdValue = -1;
	int nUserData = -1;
	int i;

	CSDEBUG(NETCMD_MODULE_NAME, INFO_LEVEL, "[%s:%d] aucCmd %s \n", __FUNCTION__, __LINE__, aucCmd);
	if (NULL == aucCmd)
	{
		CSDEBUG(NETCMD_MODULE_NAME, ERROR_LEVEL, "[%s:%d] illegal param \n", __FUNCTION__, __LINE__ );
		return EM_NETCMD_INVALPARA;
	}

	pSeperatorStart = strstr(aucCmd, "[START]#");
	pSeperatorMid 	= strchr(aucCmd, ':');
	pSeperatorEnd 	= strstr(aucCmd, "#[END]");

	if (NULL == pSeperatorStart || NULL == pSeperatorMid || NULL == pSeperatorEnd)
	{
		CSDEBUG(NETCMD_MODULE_NAME, ERROR_LEVEL, "[%s:%d] illegal param \n", __FUNCTION__, __LINE__);
		return EM_NETCMD_INVALPARA;
	}	

	nCmdType = atoi((BYTE *)(pSeperatorStart + sizeof("[START]#")-1));
	nCmdValue = atoi((BYTE *)(pSeperatorMid + sizeof(":")-1));

	for(i = 0; i < CmdNumber; i++)
	{
		if (nCmdType == CMD_NO_1[i].nCmdType)
		{
			(*pnUserData) = CMD_NO_1[i].nUserData;
			return EM_NETCMD_SUCCESS;
		}
	}

	CSDEBUG(NETCMD_MODULE_NAME, ERROR_LEVEL, "[%s:%d] illegal param \n", __FUNCTION__, __LINE__ );
	return EM_NETCMD_INVALCMD;
}

static void iNetCmdThread(void  )
{
	int  nAddrLen = -1;
	int  nRevBufLen = -1;
	int  nSendBufLen = -1;
	BYTE aucBuffer[SOCKET_CMD_MAXLEN] = {0};	
	int  nRet = -1;
	int  nStatus = -1;
	CSUDIFdSet_S fdset;
	CSUDITimeval_S tv;
	int  nMaxSocket = -1;
	
	while(1)
	{	

		nAddrLen = SOCKETADDRLEN;
		s_newfd = CSUDISOCKAccept (s_sockfd, (CSUDISockAddr_S *)&s_sClientAddr, &nAddrLen);	
		printf("---------------------------CSUDISOCKAccept %d------------------------------\n", s_newfd);
		if (-1 == s_newfd)
		{
			CSDEBUG(NETCMD_MODULE_NAME, ERROR_LEVEL, "[%s:%d] CSUDISOCKAccept failed \n", __FUNCTION__, __LINE__ );
			continue;
		}

		while(1)
		{
			// initialize file descriptor set
			CSUDI_FD_ZERO(&fdset);
			CSUDI_FD_SET(s_newfd, &fdset);
			
			// timeout setting
			tv.tv_sec	= 5;
			tv.tv_usec	= 0;
			
			nRet = CSUDISOCKSelect(s_newfd + 1, &fdset, CSUDI_NULL, CSUDI_NULL, &tv);
			if (nRet == -1) 	//error
			{
				CSDEBUG(NETCMD_MODULE_NAME, ERROR_LEVEL, "[%s:%d] CSUDISOCKSelect failed \n", __FUNCTION__, __LINE__ );
				break;
			}
			else if (nRet == 0) //time out
			{
				CSDEBUG(NETCMD_MODULE_NAME, ERROR_LEVEL, "[%s:%d] time out \n", __FUNCTION__, __LINE__ );
				continue;
			}
			
			memset(aucBuffer, 0x0, sizeof(aucBuffer));
			nRevBufLen = CSUDISOCKRecv (s_newfd, aucBuffer, sizeof (aucBuffer), 0); 
			if (nRevBufLen <= 0)
			{
				CSDEBUG(NETCMD_MODULE_NAME, ERROR_LEVEL, "[%s:%d] CSUDISOCKRecv failed \n", __FUNCTION__, __LINE__ );
				break;
			}
			printf ("Received line: %s:%d\n", aucBuffer, nRevBufLen); 

			nRet = iProcess(aucBuffer);

			iGetReturnBuffer(aucBuffer, nRet);

			nSendBufLen = CSUDISOCKSend (s_newfd, aucBuffer, strlen(aucBuffer), 0);
			if (nSendBufLen <= 0)
			{
				CSDEBUG(NETCMD_MODULE_NAME, ERROR_LEVEL, "[%s:%d] CSUDISOCKSend failed \n", __FUNCTION__, __LINE__ );
				break;
			}
			printf ("Send line: %s:%d\n", aucBuffer, nSendBufLen);
		}
		
		CSUDISOCKClose(s_newfd);
	}
}

static void iGetReturnBuffer(BYTE * aucBuffer, int nRet)
{
	int nLen = 0;
	BYTE *pucTemp = NULL;
				
	if (nRet == EM_NETCMD_INVALPARA)
	{
		memset(aucBuffer, 0x0, sizeof(aucBuffer));
		strcpy(aucBuffer, INVALCMDRTN);
	}
	else
	{
		pucTemp = strstr(aucBuffer, "#[END]");
		if (pucTemp != NULL)
		{
			sprintf(pucTemp, "#%02d", nRet);
			nLen = pucTemp-aucBuffer+3;
			aucBuffer[nLen] = '\0';
			strcat(aucBuffer, "#[END]");
		}
	}
}

