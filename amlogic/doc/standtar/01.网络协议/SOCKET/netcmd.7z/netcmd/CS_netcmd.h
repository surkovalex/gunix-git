/******************************************************************************
Copyright (c) 2010,ShenZhen Coship Electronic Ltd Co.
All rights reserved.

File Name:	CS_communicate.H
Summary: 
Current Version: $Revision$
Author: Nfer

History:
$Log$

*******************************************************************************/

#ifndef CS_COMMUNICATE_H
#define CS_COMMUNICATE_H

/******************************************************************************
 *                                 Header File Include                        *
 ******************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

#include "udi2_typedef.h"
#include "udi2_input.h"
#include "udi2_socket.h"
#include "udi2_sockerror.h"
#include "cs_hdicommon_plus.h"
/******************************************************************************
 *                                 Macro/Define/Structure                     *
 ******************************************************************************/
#define NETCMD_MODULE_NAME "NetCmd"
#undef 	CSDEBUG
#define CSDEBUG	CSDebug

/*NetCmd module return value*/
typedef enum _CSNETCMDRet_E
{
	EM_NETCMD_SUCCESS = 0,       /*�ɹ�*/
	EM_NETCMD_INVALCMD,			 /*��ֵ����*/
	EM_NETCMD_FAILURE,           /*δ֪ԭ��ʧ��*/
	EM_NETCMD_INVALPARA,         /*������Ч*/
} CSNETCMDRet_E;

typedef struct _CSCmdCode_t
{
	int 	nCmdType;
	int	 	nCmdValue;
	BOOL  	nUserData;
}CSCmdCode_t;

static CSCmdCode_t CMD_NO_1[] = 
{
	{0x01, 0x0198, CSUDI_VK_LANGUAGE},
	
	{0x02, 0x0030, CSUDI_VK_0},
	{0x03, 0x0031, CSUDI_VK_1}, 
	{0x04, 0x0032, CSUDI_VK_2}, 
	{0x05, 0x0033, CSUDI_VK_3}, 
	{0x06, 0x0034, CSUDI_VK_4}, 
	{0x07, 0x0035, CSUDI_VK_5}, 
	{0x08, 0x0036, CSUDI_VK_6},
	{0x09, 0x0037, CSUDI_VK_7}, 
	{0x0A, 0x0038, CSUDI_VK_8},
	{0x0B, 0x0039, CSUDI_VK_9},

	{0x0C, 0, 0},
	{0x0D, 0x0026, CSUDI_VK_UP}, 
	{0x0E, 0x0021, CSUDI_VK_PAGE_UP}, 
	{0x0F, 0x0F17, CSUDI_VK_STOP},	
	{0x10, 0x0028, CSUDI_VK_DOWN},
	{0x11, 0x0022, CSUDI_VK_PAGE_DOWN},
	{0x12, 0x0196, CSUDI_VK_COLORED_KEY_3}, 
	{0x13, 0x007F, CSUDI_VK_DELETE}, 
	
	{0x14, 0x0194, CSUDI_VK_COLORED_KEY_1}, 
	{0x16, 0x0F28, CSUDI_VK_SEEK},
	{0x17, 0, 0},
	{0x18, 0xFFFF, CSUDI_VK_POWER},
	{0x19, 0x0F21, CSUDI_VK_RW},
	{0x1A, 0x0F22, CSUDI_VK_FF},
	{0x1B, 0x0F18, CSUDI_VK_PAUSE},
	{0x1C, 0x0195, CSUDI_VK_COLORED_KEY_2},

	{0x1D, 0, 0}, 
	{0x1E, 0x0193, CSUDI_VK_COLORED_KEY_0},
	{0x1F, 0x000D, CSUDI_VK_OK},
	{0x20, 0x01D4, CSUDI_VK_MENU},
	{0x23, 0x0280, CSUDI_VK_TOGGLE},
	{0x24, 0x01C1, CSUDI_VK_MUTE},
	{0x25, 0x01BF, CSUDI_VK_VOLUME_UP},
	{0x26, 0x01C0, CSUDI_VK_VOLUME_DOWN},

	{0x27, 0, 0}, 
	{0x28, 0, 0},
	{0x29, 0x0025, CSUDI_VK_LEFT},
	{0x2A, 0x0027, CSUDI_VK_RIGHT},
	{0x2B, 0x01AB, CSUDI_VK_CHANNEL_UP},
	{0x2C, 0x01AC, CSUDI_VK_CHANNEL_DOWN},
	
};

#define CmdNumber sizeof(CMD_NO_1)/sizeof(CSCmdCode_t)

/******************************************************************************
 *                                 Global Function Declare                    *
 ******************************************************************************/
typedef  void ( *CSNetCmdCallback )( CSHDICallbackType , void * );

CSNETCMDRet_E CSNetCmdInit(void);

CSNETCMDRet_E CSNetCmdStart(void);

CSNETCMDRet_E CSNetCmdStop(void);

CSNETCMDRet_E CSNetCmdDestroy(void);

CSNETCMDRet_E CSNetCmdRegisterCallback( CSNetCmdCallback CmdSendCallback );




#ifdef __cplusplus
}
#endif

#endif  /* CS_NET_H */

/* End of File */
